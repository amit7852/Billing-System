# Code Citations

## License: unknown
https://github.com/mehedi7253/happy_buy/tree/fd7c9f51c198d555477e6313a51c727db85147c3/resources/views/user/orders/show.blade.php

```
>
                    <tr>
                        <th>#</th>
                        <th>Product Name</th>
                        <th>Quantity</th>
                        <th>Price</th>
                        <th>Total</th>
                    </tr>
                </thead>
                <tbody
```


## License: unknown
https://github.com/YoubaLalmas/PeterPan/tree/32c101081c01acce89b7b84747427446b4aa5c56/src/pages/invoices.jsx

```
",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(invoiceData),
        })
            .then((response) => response.json())
            .then((data) => {
                console.
```

